

class recommendation_system:
    
    def __init__(self, raw_data):
        self.raw_data = raw_data
        self.tokenized = None
        self.na_stopwords = None
        self.lemmatized = None

    def tokenize(self):
        pass

    def remove_stopwords(self):
        pass

    def lemmatize(self):
        pass

    
